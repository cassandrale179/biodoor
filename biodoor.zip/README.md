# cognizer
Face recognizer with OpenCV

## Important Note
Since this code using the latest version of OpenCV (3.3.0):
- cv2.face.LBPHFaceRecognizer_create(): method for LBHF
- pip install opencv-contrib-python: use this before using LBHF
